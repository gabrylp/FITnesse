
  # Design Interface

  This is a code bundle for Design Interface. The original project is available at https://www.figma.com/design/fhlBh3m73IKpAR2m7Wj31k/Design-Interface.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  