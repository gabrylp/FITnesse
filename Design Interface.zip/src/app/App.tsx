import React, { useState, useEffect } from 'react';
import { ArrowLeft, Calendar as CalendarIcon, User, Settings as SettingsIcon, LogOut, Check, Plus } from 'lucide-react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// --- Types ---
type Screen = 'auth' | 'home' | 'ootd' | 'calendar' | 'settings';
type ThemeMode = 'light' | 'dark' | 'system';

// --- Shared UI Components (Material 3 Emulation) ---

function TopAppBar({ title, onBack }: { title: string; onBack?: () => void }) {
  return (
    <header className="sticky top-0 z-10 flex h-16 items-center gap-4 px-4 bg-[var(--bg-color)]/90 backdrop-blur-md">
      {onBack && (
        <button 
          onClick={onBack}
          className="p-3 -ml-2 rounded-full hover:bg-[var(--md-sys-color-surface-variant)] transition-colors text-[var(--md-sys-color-on-surface)]"
        >
          <ArrowLeft size={24} />
        </button>
      )}
      <h1 className="text-[22px] font-serif font-medium text-[var(--md-sys-color-on-surface)] flex-1">{title}</h1>
    </header>
  );
}

function Card({ className, children }: { className?: string; children: React.ReactNode }) {
  return (
    <div className={cn("bg-[var(--md-sys-color-surface)] rounded-[24px] shadow-sm border border-[var(--border-color)] overflow-hidden", className)}>
      {children}
    </div>
  );
}

function Button({ children, onClick, className, variant = 'filled' }: { children: React.ReactNode, onClick?: () => void, className?: string, variant?: 'filled' | 'outlined' | 'text' }) {
  const base = "h-12 px-6 rounded-full font-sans font-medium text-sm transition-colors flex items-center justify-center";
  const variants = {
    filled: "bg-[var(--md-sys-color-primary)] text-[var(--md-sys-color-on-primary)] hover:opacity-90",
    outlined: "border border-[var(--md-sys-color-outline)] text-[var(--md-sys-color-primary)] hover:bg-[var(--md-sys-color-primary)]/10",
    text: "text-[var(--md-sys-color-primary)] hover:bg-[var(--md-sys-color-primary)]/10"
  };

  return (
    <button onClick={onClick} className={cn(base, variants[variant], className)}>
      {children}
    </button>
  );
}

function Switch({ checked, onChange }: { checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      role="switch"
      aria-checked={checked}
      onClick={() => onChange(!checked)}
      className={cn(
        "w-14 h-8 rounded-full p-1 transition-colors relative",
        checked ? "bg-[var(--md-sys-color-primary)]" : "bg-[var(--md-sys-color-surface-variant)]"
      )}
    >
      <div className={cn(
        "w-6 h-6 rounded-full shadow-md transition-transform duration-200 flex items-center justify-center",
        checked ? "translate-x-6 bg-[var(--md-sys-color-on-primary)]" : "translate-x-0 bg-[var(--md-sys-color-outline)]"
      )}>
         {checked && <Check size={14} className="text-[var(--md-sys-color-primary)]" />}
      </div>
    </button>
  );
}

// --- Screens ---

function AuthScreen({ onLogin }: { onLogin: () => void }) {
  return (
    <div className="min-h-full flex flex-col items-center justify-center p-6 text-center h-full">
      <div className="mb-12">
        <h1 className="text-5xl font-serif font-bold text-[var(--md-sys-color-primary)] mb-2">FITnesse</h1>
        <p className="text-[var(--md-sys-color-on-surface-variant)]">Your Vintage Wardrobe</p>
      </div>

      <Card className="w-full max-w-sm p-6 space-y-6">
        <h2 className="text-2xl font-serif text-[var(--md-sys-color-on-surface)] text-left">Sign in</h2>
        
        <div className="space-y-4">
          <div className="text-left">
            <label className="block text-xs font-medium text-[var(--md-sys-color-on-surface-variant)] mb-1 pl-4">Email</label>
            <input 
              type="email" 
              placeholder="you@example.com"
              className="w-full h-14 px-4 bg-[var(--bg-color)] border border-[var(--border-color)] rounded-2xl focus:outline-none focus:border-[var(--md-sys-color-primary)]"
            />
          </div>
          <div className="text-left">
            <label className="block text-xs font-medium text-[var(--md-sys-color-on-surface-variant)] mb-1 pl-4">Password</label>
            <input 
              type="password" 
              placeholder="••••••••"
              className="w-full h-14 px-4 bg-[var(--bg-color)] border border-[var(--border-color)] rounded-2xl focus:outline-none focus:border-[var(--md-sys-color-primary)]"
            />
          </div>
        </div>

        <Button className="w-full" onClick={onLogin}>Sign In</Button>
      </Card>
    </div>
  );
}

function WardrobeHome({ onNavigate }: { onNavigate: (s: Screen) => void }) {
  return (
    <div className="min-h-full flex flex-col pt-8 pb-12 px-4 items-center justify-center relative overflow-hidden h-full">
      <div className="text-center mb-10 z-10">
        <h1 className="text-3xl font-serif font-medium text-[var(--md-sys-color-on-surface)] mb-2">My Wardrobe</h1>
        <p className="text-[var(--md-sys-color-on-surface-variant)] text-sm">Tap the doors or handle to explore.</p>
      </div>

      {/* Wardrobe SVG Container */}
      <div className="relative w-full max-w-[340px] aspect-[3/4] z-10 animate-fade-in">
        <svg 
          viewBox="0 0 340 460" 
          fill="none" 
          xmlns="http://www.w3.org/2000/svg"
          className="w-full h-full drop-shadow-2xl"
        >
          {/* Wardrobe Body / Frame */}
          <rect x="10" y="20" width="320" height="420" rx="8" fill="var(--wood-color)" stroke="var(--gold-color)" strokeWidth="4"/>
          {/* Top molding */}
          <path d="M 0 20 Q 170 0 340 20 L 330 35 L 10 35 Z" fill="var(--wood-color)" stroke="var(--gold-color)" strokeWidth="2"/>
          {/* Base molding */}
          <rect x="5" y="440" width="330" height="20" rx="4" fill="var(--wood-color)" stroke="var(--gold-color)" strokeWidth="2"/>
          {/* Legs */}
          <rect x="20" y="460" width="20" height="15" fill="var(--gold-color)" />
          <rect x="300" y="460" width="20" height="15" fill="var(--gold-color)" />

          {/* Left Door */}
          <g 
            onClick={() => onNavigate('calendar')} 
            className="cursor-pointer transition-transform origin-left hover:brightness-110"
          >
            <rect x="15" y="40" width="153" height="395" fill="var(--surface-color)" stroke="var(--gold-color)" strokeWidth="2"/>
            {/* Panel details */}
            <rect x="30" y="55" width="123" height="160" rx="4" stroke="var(--gold-color)" strokeWidth="1" fill="none" opacity="0.5"/>
            <rect x="30" y="230" width="123" height="190" rx="4" stroke="var(--gold-color)" strokeWidth="1" fill="none" opacity="0.5"/>
            
            {/* Calendar Sticker */}
            <g transform="translate(80, 100) rotate(-5)">
              <rect width="32" height="32" rx="4" fill="#FFF8F0" stroke="#E2D9C8" strokeWidth="1"/>
              <path d="M8 12 H24 M8 18 H16" stroke="var(--wood-color)" strokeWidth="2" strokeLinecap="round"/>
              <rect x="10" y="6" width="4" height="6" rx="2" fill="var(--gold-color)"/>
              <rect x="18" y="6" width="4" height="6" rx="2" fill="var(--gold-color)"/>
            </g>
          </g>

          {/* Right Door */}
          <g 
            onClick={() => onNavigate('settings')} 
            className="cursor-pointer transition-transform origin-right hover:brightness-110"
          >
            <rect x="172" y="40" width="153" height="395" fill="var(--surface-color)" stroke="var(--gold-color)" strokeWidth="2"/>
            {/* Panel details */}
            <rect x="187" y="55" width="123" height="160" rx="4" stroke="var(--gold-color)" strokeWidth="1" fill="none" opacity="0.5"/>
            <rect x="187" y="230" width="123" height="190" rx="4" stroke="var(--gold-color)" strokeWidth="1" fill="none" opacity="0.5"/>
            
            {/* Profile/Silhouette Sticker */}
            <g transform="translate(230, 280) rotate(8)">
              <circle cx="16" cy="16" r="16" fill="#FFF8F0" stroke="#E2D9C8" strokeWidth="1"/>
              <circle cx="16" cy="12" r="5" fill="var(--wood-color)"/>
              <path d="M7 24 C7 19 25 19 25 24" stroke="var(--wood-color)" strokeWidth="2" strokeLinecap="round" fill="none"/>
            </g>
          </g>

          {/* Center Handle (OOTD trigger) */}
          <g 
            onClick={() => onNavigate('ootd')}
            className="cursor-pointer hover:scale-105 transition-transform origin-center"
          >
            <circle cx="170" cy="237" r="30" fill="var(--bg-color)" opacity="0.01" /> {/* Hitbox */}
            <circle cx="155" cy="237" r="6" fill="var(--gold-color)" />
            <circle cx="185" cy="237" r="6" fill="var(--gold-color)" />
            <rect x="153" y="217" width="4" height="40" rx="2" fill="var(--gold-color)" />
            <rect x="183" y="217" width="4" height="40" rx="2" fill="var(--gold-color)" />
          </g>
        </svg>
      </div>

      {/* Decorative backdrop */}
      <div className="absolute top-0 left-0 w-full h-[50vh] bg-gradient-to-b from-[var(--md-sys-color-primary)]/10 to-transparent pointer-events-none -z-10" />
    </div>
  );
}

function OOTDScreen({ onBack }: { onBack: () => void }) {
  return (
    <div className="min-h-full pb-12">
      <TopAppBar title="Today's Outfit" onBack={onBack} />
      
      <div className="px-4 mt-6 animate-slide-up">
        <Card className="p-6">
          <h2 className="text-xl font-serif text-[var(--md-sys-color-on-surface)] mb-6">Recommended</h2>
          
          {/* Mannequin Layout */}
          <div className="bg-[var(--md-sys-color-surface-variant)] rounded-[32px] p-6 flex justify-center items-center gap-4 mb-8">
            
            {/* Center Column: Head to toe */}
            <div className="flex flex-col items-center gap-4 w-1/2">
              <div className="flex flex-col items-center w-full">
                <span className="text-[var(--md-sys-color-on-surface-variant)] text-[10px] font-bold mb-1.5 uppercase tracking-widest">Top</span>
                <div className="w-full max-w-[100px] h-24 border-2 border-dashed border-[var(--md-sys-color-outline)] rounded-xl opacity-60 bg-[var(--md-sys-color-surface)]" />
              </div>
              <div className="flex flex-col items-center w-full">
                <span className="text-[var(--md-sys-color-on-surface-variant)] text-[10px] font-bold mb-1.5 uppercase tracking-widest">Bottom</span>
                <div className="w-full max-w-[100px] h-32 border-2 border-dashed border-[var(--md-sys-color-outline)] rounded-xl opacity-60 bg-[var(--md-sys-color-surface)]" />
              </div>
              <div className="flex flex-col items-center w-full">
                <span className="text-[var(--md-sys-color-on-surface-variant)] text-[10px] font-bold mb-1.5 uppercase tracking-widest">Shoes</span>
                <div className="w-full max-w-[100px] h-16 border-2 border-dashed border-[var(--md-sys-color-outline)] rounded-xl opacity-60 bg-[var(--md-sys-color-surface)]" />
              </div>
            </div>

            {/* Side Column: Outerwear */}
            <div className="flex flex-col items-center w-1/2 justify-center h-full">
              <span className="text-[var(--md-sys-color-on-surface-variant)] text-[10px] font-bold mb-1.5 uppercase tracking-widest">Outerwear</span>
              <div className="w-full max-w-[110px] h-[304px] border-2 border-dashed border-[var(--md-sys-color-outline)] rounded-xl opacity-60 bg-[var(--md-sys-color-surface)]" />
            </div>

          </div>

          {/* Gemini Reasoning */}
          <div className="bg-gradient-to-br from-[var(--md-sys-color-primary)]/10 to-transparent p-5 rounded-2xl mb-8 border border-[var(--md-sys-color-primary)]/20">
             <p className="font-serif italic text-[var(--md-sys-color-on-surface)] text-[15px] leading-relaxed">
               "Given the crisp 62°F forecast and your casual dinner plans, this warm earthy palette perfectly balances comfort and vintage style. The dark denim anchors the look, while the cream sweater adds texture."
             </p>
             <div className="mt-3 flex items-center gap-2">
               <span className="text-[10px] uppercase tracking-wider font-bold text-[var(--md-sys-color-primary)]">✧ Curated by Gemini</span>
             </div>
          </div>

          <div className="flex flex-col gap-3">
            <Button variant="outlined" className="w-full text-base flex justify-center items-center gap-2">
              <Plus size={18} />
              Add Clothes
            </Button>
            <Button className="w-full text-base">Mark as Worn</Button>
          </div>
        </Card>
      </div>
    </div>
  );
}

function CalendarScreen({ onBack }: { onBack: () => void }) {
  const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  
  return (
    <div className="min-h-full pb-12">
      <TopAppBar title="Calendar" onBack={onBack} />
      
      <div className="px-4 mt-6 animate-slide-up">
        {/* Weekly View Grid */}
        <h3 className="font-sans font-medium text-sm text-[var(--md-sys-color-on-surface-variant)] uppercase tracking-widest mb-4 ml-2">This Week</h3>
        <div className="flex gap-3 overflow-x-auto pb-4 snap-x hide-scrollbar">
          {days.map((day, i) => (
            <div key={day} className={cn(
              "snap-center shrink-0 w-[72px] h-[90px] rounded-2xl flex flex-col items-center justify-center gap-1 border",
              i === 3 ? "bg-[var(--md-sys-color-primary)] text-[var(--md-sys-color-on-primary)] border-transparent shadow-md" : "bg-[var(--md-sys-color-surface)] border-[var(--border-color)] text-[var(--md-sys-color-on-surface)]"
            )}>
              <span className="text-xs font-medium opacity-80">{day}</span>
              <span className="text-xl font-serif">{12 + i}</span>
              <div className={cn("w-1 h-1 rounded-full mt-1", i <= 3 ? "bg-current opacity-50" : "bg-transparent")} />
            </div>
          ))}
        </div>

        {/* History Log */}
        <h3 className="font-sans font-medium text-sm text-[var(--md-sys-color-on-surface-variant)] uppercase tracking-widest mt-6 mb-4 ml-2">Past Outfits</h3>
        <div className="space-y-4">
          {[1, 2, 3].map((_, idx) => (
            <Card key={idx} className="p-4 flex gap-4 items-center active:scale-[0.98] transition-transform cursor-pointer">
              <div className="w-16 h-16 rounded-xl bg-[var(--md-sys-color-surface-variant)] flex-shrink-0 border border-[var(--border-color)] overflow-hidden flex flex-wrap">
                 {/* Mini thumbnails collage simulation */}
                 <div className="w-1/2 h-1/2 bg-[var(--wood-color)]/20" />
                 <div className="w-1/2 h-1/2 bg-[var(--gold-color)]/20" />
                 <div className="w-1/2 h-1/2 bg-[var(--md-sys-color-on-surface)]/10" />
                 <div className="w-1/2 h-1/2 bg-[var(--md-sys-color-primary)]/30" />
              </div>
              <div className="flex-1">
                <h4 className="font-serif text-[17px] text-[var(--md-sys-color-on-surface)]">Autumn Casual</h4>
                <p className="text-sm text-[var(--md-sys-color-on-surface-variant)] mt-0.5">Oct {14 - idx} • 4 items</p>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}

function SettingsScreen({ onBack, theme, setTheme, onSignOut }: { 
  onBack: () => void, 
  theme: ThemeMode, 
  setTheme: (t: ThemeMode) => void,
  onSignOut: () => void
}) {
  const [laundryCooldown, setLaundryCooldown] = useState(true);
  const [cooldownDays, setCooldownDays] = useState(4);

  return (
    <div className="min-h-full pb-12">
      <TopAppBar title="Settings" onBack={onBack} />
      
      <div className="px-4 mt-6 animate-slide-up space-y-6">
        
        {/* Profile Card */}
        <Card className="p-5 flex items-center gap-4">
          <div className="w-14 h-14 rounded-full bg-[var(--md-sys-color-primary)]/20 flex items-center justify-center text-[var(--md-sys-color-primary)]">
            <User size={24} />
          </div>
          <div>
            <h3 className="font-serif text-lg text-[var(--md-sys-color-on-surface)]">user@example.com</h3>
            <p className="text-sm text-[var(--md-sys-color-on-surface-variant)]">Free Vintage Plan</p>
          </div>
        </Card>

        {/* Preferences */}
        <div>
          <h3 className="font-sans font-medium text-sm text-[var(--md-sys-color-primary)] uppercase tracking-widest mb-3 ml-4">Preferences</h3>
          <Card className="divide-y divide-[var(--border-color)]">
            
            <div className="p-5 flex items-center justify-between">
              <div>
                <p className="font-medium text-[var(--md-sys-color-on-surface)] text-[16px]">Laundry Cooldown</p>
                <p className="text-sm text-[var(--md-sys-color-on-surface-variant)] mt-0.5">Exclude recently worn items</p>
              </div>
              <Switch checked={laundryCooldown} onChange={setLaundryCooldown} />
            </div>

            {laundryCooldown && (
              <div className="p-5 pt-4">
                <div className="flex justify-between mb-4">
                  <p className="text-[15px] text-[var(--md-sys-color-on-surface)]">Cooldown Duration</p>
                  <p className="font-medium text-[var(--md-sys-color-primary)]">{cooldownDays} days</p>
                </div>
                <input 
                  type="range" 
                  min="3" max="7" 
                  value={cooldownDays} 
                  onChange={(e) => setCooldownDays(parseInt(e.target.value))}
                  className="w-full accent-[var(--md-sys-color-primary)]"
                />
                <div className="flex justify-between mt-2 text-xs text-[var(--md-sys-color-on-surface-variant)]">
                  <span>3 days</span>
                  <span>7 days</span>
                </div>
              </div>
            )}

            <div className="p-5">
               <p className="font-medium text-[var(--md-sys-color-on-surface)] text-[16px] mb-4">Theme</p>
               <div className="flex bg-[var(--md-sys-color-surface-variant)] rounded-xl p-1">
                 {['light', 'dark', 'system'].map((t) => (
                   <button
                     key={t}
                     onClick={() => setTheme(t as ThemeMode)}
                     className={cn(
                       "flex-1 py-2 text-sm font-medium rounded-lg capitalize transition-all",
                       theme === t 
                         ? "bg-[var(--md-sys-color-surface)] text-[var(--md-sys-color-on-surface)] shadow-sm" 
                         : "text-[var(--md-sys-color-on-surface-variant)] hover:bg-[var(--md-sys-color-surface)]/50"
                     )}
                   >
                     {t}
                   </button>
                 ))}
               </div>
            </div>

          </Card>
        </div>

        <div className="pt-4">
           <Button variant="outlined" className="w-full border-red-500/50 text-red-600 hover:bg-red-500/10" onClick={onSignOut}>
             <LogOut size={18} className="mr-2" />
             Sign Out
           </Button>
        </div>

      </div>
    </div>
  );
}

// --- Main App Component ---

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('auth');
  const [theme, setTheme] = useState<ThemeMode>('system');

  // Handle Theme
  useEffect(() => {
    const root = window.document.documentElement;
    root.classList.remove('light', 'dark');
    
    if (theme === 'system') {
      const systemTheme = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
      root.classList.add(systemTheme);
    } else {
      root.classList.add(theme);
    }
  }, [theme]);

  // Handle Android back button emulation via browser history (simple version)
  useEffect(() => {
    if (currentScreen !== 'auth') {
      window.history.pushState({ screen: currentScreen }, '');
    }
    const handlePopState = (e: PopStateEvent) => {
      if (currentScreen === 'home') {
        // stay
      } else if (currentScreen !== 'auth') {
        setCurrentScreen('home');
      }
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, [currentScreen]);

  return (
    <div className="min-h-screen bg-neutral-200 dark:bg-neutral-900 flex items-center justify-center sm:p-8 font-sans transition-colors duration-300">
      
      {/* Device Emulator Frame (Medium Phone - 412x915 dp equivalent) */}
      <div className="w-full h-[100dvh] sm:w-[412px] sm:h-[915px] sm:max-h-[90vh] bg-[var(--bg-color)] text-[var(--text-primary)] sm:rounded-[36px] sm:border-[12px] sm:border-gray-800 shadow-2xl relative flex flex-col overflow-hidden">
        
        {/* Dynamic styles to add global animations */}
        <style>{`
          .hide-scrollbar::-webkit-scrollbar { display: none; }
          .hide-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
          
          @keyframes fade-in {
            from { opacity: 0; }
            to { opacity: 1; }
          }
          @keyframes slide-up {
            from { opacity: 0; transform: translateY(16px); }
            to { opacity: 1; transform: translateY(0); }
          }
          
          .animate-fade-in { animation: fade-in 0.4s ease-out forwards; }
          .animate-slide-up { animation: slide-up 0.5s cubic-bezier(0.2, 0.8, 0.2, 1) forwards; }
        `}</style>

        {/* Screen Content Wrapper */}
        <div className="flex-1 overflow-y-auto hide-scrollbar relative bg-[var(--bg-color)]">
          {currentScreen === 'auth' && <AuthScreen onLogin={() => setCurrentScreen('home')} />}
          {currentScreen === 'home' && <WardrobeHome onNavigate={setCurrentScreen} />}
          {currentScreen === 'ootd' && <OOTDScreen onBack={() => setCurrentScreen('home')} />}
          {currentScreen === 'calendar' && <CalendarScreen onBack={() => setCurrentScreen('home')} />}
          {currentScreen === 'settings' && <SettingsScreen onBack={() => setCurrentScreen('home')} theme={theme} setTheme={setTheme} onSignOut={() => setCurrentScreen('auth')} />}
        </div>

      </div>
    </div>
  );
}
