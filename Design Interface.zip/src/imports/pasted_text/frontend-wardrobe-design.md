# Frontend.md - Wardrobe Interface Design & Build

## Role Overview
Owns the UI/UX implementation of FITnesse's core visual concept: an old-fashioned wardrobe that serves as the app's main interface. This role handles wireframing, layout, theming, and navigation wiring, working under the backend role's architecture guidance (ViewModels and data contracts will be provided/agreed upon before UI work starts).

## Core Design Concept
The entire app is framed as a physical wardrobe illustration on the home screen, with interactive elements replacing traditional nav bars:
- **Wardrobe handle**: tapping/pulling it opens the Main/OOTD screen, where the day's recommended outfit "pops out"
- **Left door (calendar sticker)**: tapping this door opens the Calendar screen (includes History - past outfit log and weekly view)
- **Right door (profile sticker)**: tapping this door opens Settings/Profile
- This wardrobe illustration effectively replaces a bottom nav bar/drawer with a themed, illustrated interaction model

## Theme
- **Light mode**: white and gold, old-fashioned/vintage wardrobe styling (wood-grain accents, ornate handle details, warm gold trim)
- **Dark mode**: black and gold, same vintage wardrobe silhouette with darker wood tones and gold accents for contrast
- Maintain Material 3 theming underneath (color tokens, typography scale) while applying the custom wardrobe illustration as the primary visual layer

## Tools to Use
- **Wireframing**: Figma (free tier) - sketch the wardrobe illustration concept and interaction states (closed, door-open, handle-pulled) before coding
- **Illustration assets**: Figma or free tools like Canva/Inkscape for the vintage wardrobe graphic (doors, handle, stickers); consider free asset packs or hand-drawn vector illustration if no one on the team can illustrate
- **UI implementation**: Android Studio, Jetpack Compose (preferred) with custom Composables for the wardrobe illustration and door/handle animations
- **Design reference**: Material 3 design kit in Figma (free, official Google community file) for underlying components (buttons, forms, cards) inside each screen
- **Icons**: Material Symbols (free, Google) for smaller in-screen icons, layered on top of the custom wardrobe theme
- **Animation**: Jetpack Compose Animation APIs (free, built-in) for door-opening and item-popping transitions

## Deliverables

### 1. Wireframes & Illustration Concept (Week 5)
- Sketch the wardrobe home screen: closed state, door-open states, handle-pull animation concept
- Wireframe the 3 screens it leads to: Main/OOTD, Calendar/History, Settings/Profile
- Share in Figma, get feedback from the backend role before building

### 2. Wardrobe Home Screen (Custom Interactive Component)
- Build the illustrated wardrobe as the app's landing view
- Implement tap/animation interactions: handle -> Main/OOTD, calendar-sticker door -> Calendar/History, profile-sticker door -> Settings/Profile
- Ensure the illustration and interactions adapt correctly between light (white/gold) and dark (black/gold) themes

### 3. Main/OOTD Screen
- Displays today's outfit recommendation "popping out" of the wardrobe visually (card or modal style with an opening animation)
- Shows Gemini-generated reasoning text alongside the outfit

### 4. Calendar/History Screen
- Weekly view showing recommended outfit thumbnail per day
- Includes historical log of past worn outfits, with confirm/mark-as-worn interaction
- Tap a day to expand full outfit detail + reasoning

### 5. Settings/Profile Screen
- Account settings, laundry cooldown toggle and duration adjustment
- Theme toggle (light/dark, white-gold/black-gold) if not handled automatically by system settings

### 6. Navigation Wiring
- Implement the wardrobe illustration as the primary navigation hub instead of a standard nav bar
- Use Jetpack Navigation Component to manage transitions between the 3 screens and back to the wardrobe home view

## Data Contract (Coordinate with the Backend Role)
- Confirm exact field names/types in ClothingItem, OutfitRecommendation, and UserSettings before building UI, so ViewModel integration is a drop-in step later
- Build screens against sample/mock data first; the backend role will wire real Firestore/Gemini data once UI is stable

## Weekly Plan

| Week | Task |
|---|---|
| Week 5 | Create wardrobe illustration concept and wireframes for all 3 screens; confirm data contract and theme colors with the backend role |
| Week 6 | Build the wardrobe home screen with door/handle interactions using mock data; implement navigation wiring |
| Week 7 | Integrate real ViewModel data (provided by the backend role); polish animations, finalize light/dark theme styling |
| Week 8 | Bug fixes from QA feedback; final responsive testing across screen sizes and both themes |

## Plan: Suggested AI Prompts
If using AI tools to get more detail on this role's tasks, consider prompting:
- "Describe how to design an interactive illustrated wardrobe UI in Jetpack Compose, where tapping different parts (handle, doors) navigates to different screens."
- "Suggest a vintage/old-fashioned wardrobe color palette for light mode (white and gold) and dark mode (black and gold) following Material 3 theming principles."
- "Explain how to implement door-opening and pop-out animations in Jetpack Compose for a custom illustrated navigation component."
- "Generate a Figma wireframe structure for an app with one illustrated home screen (a wardrobe) leading to 3 sub-screens: outfit recommendation, calendar/history, and settings."
- "What's the best way to build custom non-standard navigation (replacing a bottom nav bar) in Android using Jetpack Navigation Component?"

## Checklist Before Marking Done
- Wardrobe illustration and interactions match approved wireframes
- All 3 screens reachable from the wardrobe home screen with smooth animation, and returnable without dead ends
- Light mode (white/gold) and dark mode (black/gold) both fully styled and tested
- Empty states handled (e.g., "No items yet" in Calendar/History if wardrobe is empty)
- Tested on at least 2 different screen sizes/emulators
